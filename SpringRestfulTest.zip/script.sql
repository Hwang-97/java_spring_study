-- SpringRestfulTest > "script.sql"

